create view tview as
  select `db1`.`teacher`.`tid` AS `tid`, `db1`.`teacher`.`name` AS `NAME`
  from `db1`.`teacher`;

