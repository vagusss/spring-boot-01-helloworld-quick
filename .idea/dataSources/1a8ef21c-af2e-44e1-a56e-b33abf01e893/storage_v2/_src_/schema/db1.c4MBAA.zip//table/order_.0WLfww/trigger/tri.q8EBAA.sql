create trigger tri
  after INSERT
  on order_
  for each row
  begin
update goods set count_ = count_ -1 where gid = 10;
end;

