create procedure test3()
  begin
	declare a int;
	declare b int;
	declare z int;
	set a = 3;
	set b = 4;
	-- set z = a + b;
	
	select a+ b;
end;

