create function fun1(a int, b int)
  returns int
  begin
	return a+b;
end;

