create function aadd(a int, b int)
  returns int
  begin
return a + b;
end;

