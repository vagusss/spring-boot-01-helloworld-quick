create procedure test1()
  begin
	IF 4>3 THEN
        SELECT * from student;
END IF;
end;

