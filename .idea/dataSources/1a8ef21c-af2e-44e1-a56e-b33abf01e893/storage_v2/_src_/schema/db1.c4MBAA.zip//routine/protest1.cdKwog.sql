create procedure protest1(IN n int)
  begin
declare i int default 1;
declare sum_ int default 0;
while i<=n do
set sum_ = sum_ + i;
set i = i + 1;
end while;
select sum_;
end;

