create procedure test2(IN a int, IN b int)
  begin
	
	
	select a+b;
end;

