create view ssview as
  select `db1`.`student`.`stuid` AS `stuid`,
         `db1`.`student`.`name`  AS `name`,
         `db1`.`student`.`tid`   AS `tid`,
         `db1`.`student`.`score` AS `score`,
         `db1`.`student`.`cid`   AS `cid`
  from `db1`.`student`;

