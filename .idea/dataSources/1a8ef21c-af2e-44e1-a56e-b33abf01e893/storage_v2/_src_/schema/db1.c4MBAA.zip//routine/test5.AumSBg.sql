create procedure test5()
  begin
	declare n int default 100;
	call test4(n);
	select n;
end;

