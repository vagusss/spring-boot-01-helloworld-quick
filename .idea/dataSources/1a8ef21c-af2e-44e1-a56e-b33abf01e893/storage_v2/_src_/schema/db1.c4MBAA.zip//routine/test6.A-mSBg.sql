create procedure test6()
  BEGIN
	declare a int default 4;
	declare b int default 3;
	declare c int;
	select IF(4>3,a,b);
	
        
	
END;

