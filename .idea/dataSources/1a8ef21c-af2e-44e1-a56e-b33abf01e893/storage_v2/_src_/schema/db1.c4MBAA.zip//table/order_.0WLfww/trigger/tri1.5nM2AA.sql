create trigger tri1
  before INSERT
  on order_
  for each row
  begin
if new.count_ >5 then 
set new.count_ = 5;
end if;
end;

