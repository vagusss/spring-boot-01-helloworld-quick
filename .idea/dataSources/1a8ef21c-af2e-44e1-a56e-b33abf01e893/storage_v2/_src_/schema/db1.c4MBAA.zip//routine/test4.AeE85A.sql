create procedure test4(INOUT n int)
  begin
	declare i int default 1;
	declare sum_  int default 0;
	lable1 : loop
	if i>n then leave lable1;
	end if;
	set sum_ = sum_ + i;
	set i = i+1;
	end loop;
	set n = sum_;
	
end;

